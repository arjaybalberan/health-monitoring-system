<div class="p-6">
    <div class="flex justify-end">
        <x-jet-button class="" wire:click="showCreateModal">
            {{ __('Add Resident') }}
        </x-jet-button>
    </div>

   {{-- The data table --}}
    <div class="flex flex-col mt-6">
        <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">

                    <table class="min-w-full divide-y divide-gray-200">
                        <thead>
                            <tr class="text-left">
                                <th class="px-6 py-3 bg-gray-50 text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Full Name</th>
                                <th class="px-6 py-3 bg-gray-50 text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Phone Number</th>
                                <th class="px-6 py-3 bg-gray-50 text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Email</th>
                                <th class="px-6 py-3 bg-gray-50 text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">Action</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            @if ($data->count())
                                @foreach ($data as $resident)
                                    <tr>
                                        <td class="px-6 py-4 text-sm whitespace-no-wrap font-medium">
                                            {{ $resident->first_name }} {{ $resident->middle_name }} {{ $resident->last_name }}
                                        </td>

                                        <td class="px-6 py-4 text-sm whitespace-no-wrap font-medium">
                                            {{ $resident->phone_number }}
                                        </td>

                                        <td class="px-6 py-4 text-sm whitespace-no-wrap font-medium">
                                            {{ $resident->email }}
                                        </td>

                                        <td class="px-6 py-4 text-sm flex gap-2">
                                            <x-jet-danger-button wire:click="removeResident({{ $resident->id }})">
                                                {{ __('Remove') }}
                                            </x-jet-button>
                                        </td>
                                    </tr>
                                @endforeach
                            @else
                                <tr>
                                    <td class="px-6 py-4 text-sm whitespace-no-wrap text-center" colspan="4">No Results Found</td>
                                </tr>
                            @endif

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <!-- Match Modal -->
    <x-jet-dialog-modal wire:model="createModalVisible" maxWidth="2xl">
        <x-slot name="title">
            {{ __('Add Resident') }}
        </x-slot>

        <x-slot name="content">
            <!-- First Name -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-2">
                <div class="">
                    <x-jet-label for="last_name" value="{{ __('Lastname') }}" />
                    <x-jet-input id="last_name" type="text" class="mt-2 block w-full" wire:model.defer="last_name" required autofocus />
                    <x-jet-input-error for="last_name" class="mt-2" />
                </div>
                <div class="">
                    <x-jet-label for="first_name" value="{{ __('Firstname') }}" />
                    <x-jet-input id="first_name" type="text" class="mt-2 block w-full" wire:model.defer="first_name" required autofocus />
                    <x-jet-input-error for="first_name" class="mt-2" />
                </div>
                <div class="">
                    <x-jet-label for="middle_name" value="{{ __('Middlename') }}" />
                    <x-jet-input id="middle_name" type="text" class="mt-2 block w-full" wire:model.defer="middle_name" required autofocus />
                    <x-jet-input-error for="middle_name" class="mt-2" />
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-2 mt-2">
                <div class="">
                    <x-jet-label for="email" value="{{ __('Email') }}" />
                    <x-jet-input id="email" type="email" class="mt-2 block w-full" wire:model.defer="email" required autofocus />
                    <x-jet-input-error for="email" class="mt-2" />
                </div>
                <div class="">
                    <x-jet-label for="phone_number" value="{{ __('Phone Number') }}" />
                    <x-jet-input id="phone_number" type="text" class="mt-2 block w-full" wire:model.defer="phone_number" required autofocus />
                    <x-jet-input-error for="phone_number" class="mt-2" />
                </div>
            </div>

            <div class="grid grid-cols-1 mt-2">
                <div class="">
                    <x-jet-label for="address" value="{{ __('Address') }}" />
                    <x-jet-input id="address" type="text" class="mt-2 block w-full" wire:model.defer="address" required autofocus />
                    <x-jet-input-error for="address" class="mt-2" />
                </div>
            </div>

        </x-slot>

        <x-slot name="footer">
            <x-jet-button wire:click="addResident()">
                {{ __('Confirm') }}
            </x-jet-button>

            <x-jet-secondary-button wire:click="$toggle('createModalVisible')" wire:loading.attr="disabled">
                {{ __('Cancel') }}
            </x-jet-secondary-button>
        </x-slot>
    </x-jet-dialog-modal>
</div>
