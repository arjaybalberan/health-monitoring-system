<?php

namespace App\Http\Livewire;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;
use Illuminate\Validation\Rule;

class Residents extends Component
{
    public $createModalVisible = false;
    public $first_name;
    public $middle_name;
    public $last_name;
    public $email;
    public $phone_number;
    public $address;

    public function rules()
    {
        return [
            'email' => ['required','email',Rule::unique('users','email')],
            'first_name' => ['required'],
            'middle_name' => ['required'],
            'last_name' => ['required'],
            'phone_number' => ['required','numeric',Rule::unique('users','phone_number')],
            'address' => ['required'],
        ];
    }

    public function showCreateModal()
    {
        $this->createModalVisible = true;
    }

    public function read()
    {
        return User::where('role','resident')
        ->orderBy('last_name')
        ->get();
    }

    public function addResident()
    {
        $this->validate();

        User::Create([
            'first_name' => $this->first_name,
            'middle_name' => $this->middle_name,
            'last_name' => $this->last_name,
            'phone_number' => $this->phone_number,
            'email' => $this->email,
            'address' => $this->address,
            'role' => 'resident',
            'password' => Hash::make('Dev123'),
        ]);

        $this->clear();

        $this->createModalVisible = false;
    }

    public function removeResident($resident_id)
    {
        User::findorFail($resident_id)->delete();

        $this->clear();
    }

    public function clear()
    {
        $this->first_name = NULL;
        $this->middle_name = NULL;
        $this->last_name = NULL;
        $this->address = NULL;
        $this->phone_number = NULL;
        $this->email = NULL;
    }

    public function render()
    {
        return view('livewire.residents', ['data' => $this->read()]);
    }
}
